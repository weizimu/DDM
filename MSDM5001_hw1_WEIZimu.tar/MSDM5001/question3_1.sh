#! /bin/bash
grep "blockID=\"[gi].*[0-9]\"[[:space:]|>]" blocklist.xml
