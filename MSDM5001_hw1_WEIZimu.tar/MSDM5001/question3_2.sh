#! /bin/bash
grep "id=\"[a-zA-Z0-9_\-\.\+]\+@[a-zA-Z0-9_\-\.]\+\.[a-zA-Z]\+" blocklist.xml

